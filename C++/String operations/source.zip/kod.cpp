//Jan Skwarczek

#include <string>

using namespace std;

string NajwiekszeSlowo(string napis){
	
	string retvalue = napis;
	long long spacescounter = 0;

	int i = 0;
	int index = 0;
	
	for(int i=0; i<napis.size(); i++){
		
		if(napis[i]==' ') spacescounter++;
		
	}
	
	string wyrazy[spacescounter+1];
	
	while(i<napis.size()){
        
		if(napis[i]!=' '){
        	
			wyrazy[index]+=napis[i];
        	i++;
		}
		
        else{
        	
            index++;
            i++;
        }
	}

	retvalue = wyrazy[0];
	
	for(int i=0; i<=spacescounter; i++){
		
		if(wyrazy[i]>=retvalue) retvalue = wyrazy[i];
		
	}
	
	return retvalue;
	
}

string UsunSlowo(string napis, int miejsce){
	
	bool prevspace = (napis[0] == ' ');
    
	if (!prevspace) {
        miejsce--;
    }

    string retvalue;
	 
    for (int i=0; i<napis.size(); ++i){
        
		if (prevspace && napis[i]!=' '){
            miejsce--;
        }
        
        if (miejsce!=0 || napis[i]==' '){
            retvalue += napis[i];
        }
        
        prevspace = napis[i] == ' ';
    }

    return retvalue;
}
	
string NormalizujNapis(string napis){
	
	string retvalue;
	
	long long spacescounter = 0;

	int i = 0;
	int index = 0;
	
	for(int i=0; i<napis.size(); i++){
		
		if(napis[i]==' ') spacescounter++;
		
	}
	
	string wyrazy[spacescounter+1];
	
	while(i<napis.size()){
        
		if(napis[i]!=' '){
        	
			wyrazy[index]+=napis[i];
        	i++;
		}
		
        else{
        	
            index++;
            i++;
            wyrazy[index] = '?';
        }
	}
	
	for(int i=0; i<=index; i++){
		
		retvalue += wyrazy[i];
		
	}
	
	for(int i=0; i<retvalue.size(); i++){
		
		if(retvalue[0]=='?'){
			
			for(int j=0; j<retvalue.size(); j++){
				
				retvalue[j] = retvalue[j+1];
				
			}
			retvalue.resize(retvalue.size()-1);
		}
		
		if((retvalue[i]=='?')&&(retvalue[i+1]=='?')){
			
			for(int j=i; j<retvalue.size(); j++){
				
				retvalue[j] = retvalue[j+1];
				
			}
			
			retvalue.resize(retvalue.size()-1);
			i=-1;
		}
		
		if((retvalue[i]=='?')&&(retvalue[i+1]=='.')){
			
			retvalue[i] = '.';
			retvalue[i+1] = '?';
						
		}
		
		if((retvalue[i]=='?')&&(retvalue[i+1]==',')){
			
			retvalue[i] = ',';
			retvalue[i+1] = '?';
						
		}
		
		if(retvalue[retvalue.size()-1]=='?'){
			
			retvalue.resize(retvalue.size()-1);

		}
		
	}
	
	for(int i=0; i<retvalue.size(); i++){
		
		if(retvalue[i]=='?'){
			
			retvalue[i]=' ';
			
		}
		
	}
	
	int spacedot = 0;
	
	for(int i=0; retvalue[i]!='\0'; i++){
	
		if((retvalue[i]=='.')&&(retvalue[i+1]!=' ') || (retvalue[i]==',')&&(retvalue[i+1]!=' ')){
			
			spacedot++;
			
		}
	
	}
	
	retvalue.resize(retvalue.size()+spacedot);
	
	for(int i=0; retvalue[i]!='\0'; i++){
		
		if((retvalue[i]=='.')&&(retvalue[i+1]!=' ')&&(retvalue[i+1]!=' ')|| (retvalue[i]==',')&&(retvalue[i+1]!=' ')){
			
			for(int j=retvalue.size()-1; j>i; j--){
				
				retvalue[j] = retvalue[j-1];
				
			}
			
			retvalue[i+1] = ' ';
			i++;
		}
		
	}
	
	if(retvalue[retvalue.size()-1]==' ') retvalue.resize(retvalue.size()-1);
	
	
	
	return retvalue;
	
}

string FormatujNapis(string napis, string tekst1, string tekst2, string tekst3) {

    string retvalue;
    retvalue = napis;

    for (int i = 0; i < retvalue.size(); i++){
        
		if (retvalue[i] == '{'){
			
            if (retvalue[i + 1] == 'p'){
            	
                int amount = retvalue[i+3] - '0';
                char sign = retvalue[i+5];

                string beforebrackets;
                string repeat;
                string afterbrackets;

                for (int k=0; k<i; k++){
                    beforebrackets += retvalue[k];

                }
                for (int j=0; j<retvalue.size() - i - 7; j++){

                    afterbrackets += retvalue[i+j+7];
                }

                for (int l=0; l<amount; ++l){

                    repeat += sign;
                }

                beforebrackets += repeat;
                retvalue = beforebrackets + afterbrackets;

                i += amount - 1;

            }
            if (retvalue[i+1] == 'u'){
            	
                int amount = retvalue[i+3] - '0';
                string beforebrackets;
                string afterbrackets;

                for (int k=0; k<i; ++k){
                	
                    beforebrackets += retvalue[k];
                }

                for (int j = 5 + i + amount; j<retvalue.size(); j++){
                	
                    afterbrackets += retvalue[j];
                }

                retvalue = beforebrackets + afterbrackets;
                
                i = 0;
            }
            
            if (retvalue[i + 1] == 'U'){
				
				int counter = 0;
				
				for(int k=0; k<retvalue[k]!='\0'; k++) counter++;
				
				if(retvalue[i+3] - '0' > counter) retvalue[i+3] = counter;
				
                if (retvalue[1] == 'U'){
                	
                    string napis1;
                    
                    for (int j=i+4; j<retvalue.size(); j++){
                    	
                        napis1 += retvalue[j];
                    }
                    
                    retvalue = napis1;
                    i = 0;
                }
                
                else{

                    int amount = retvalue[i+3] - '0';

                    string beforebrackets;
                    string afterbrackets;

                    for (int k=0; k < i - amount; k++){
                    	
                        beforebrackets += retvalue[k];
                    }

                    for (int j = 5+i; j<retvalue.size(); j++){
                    	
                        afterbrackets += retvalue[j];
                    }

                    retvalue = beforebrackets + afterbrackets;
                    i = 0;
                }

            }
            if (retvalue[i+1] == 'w'){
            	
                int amount = retvalue[i+3] - '0';
                string beforebrackets;
                string afterbrackets;

                string parametr;

                if (amount == 1){
                	
                    parametr = tekst1;
                    
                }
				
				else if (amount == 2){
					
                    parametr = tekst2;
                }
				
				else if (amount == 3){
					
                    parametr = tekst3;
                }

                for (int j=0; j<i; j++){
                    beforebrackets += retvalue[j];
                }
                for (int k = i+5; k<retvalue.size(); k++){
                	
                    afterbrackets += retvalue[k];
                }

                retvalue = beforebrackets + parametr + afterbrackets;
                i = 0;

            }
            if (retvalue[i + 1] == 'W'){
            	
                int amount = retvalue[i+3] - '0';
                int dlugosc = retvalue[i+5] - '0';

                string parametr;
                string beforebrackets;
                string afterbrackets;

                if (amount == 1){
                	
                    parametr = tekst1;
                }
				
				else if (amount == 2){
					
                    parametr = tekst2;
                }
				
				else if (amount == 3){
					
                    parametr = tekst3;
                }
                
                parametr.resize(dlugosc, ' ');

                for (int j=0; j<i; j++){
                    beforebrackets += retvalue[j];
                }
                
                for (int k = i+7; k<retvalue.size(); k++){
                	
                    afterbrackets += retvalue[k];
                }

                retvalue = beforebrackets + parametr + afterbrackets;
                i = 0;
                
                }
                
                i--;
            }
            
        }
    return retvalue;
    }

