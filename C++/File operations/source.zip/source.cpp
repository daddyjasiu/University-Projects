//Jan Skwarczek

const int INT_MAKS = 2147483647;


using namespace std;

struct Zestaw
{
    bool b;
    unsigned int c;
    float f;
    bool obetnij()
    {
        c %= 256;
        return true;
    }
};

struct Dana
{
    int liczba;
    string slowo;
    string litera;
    Zestaw zestaw1;
    Zestaw zestaw2;
    Zestaw zestaw3;
    Zestaw zestaw4;
};

void kopiujPlik(string nazwa1, string nazwa2)
{
    ifstream in(nazwa1.c_str());
    ofstream out(nazwa2.c_str());
    string linia;
    while (getline(in, linia))
    {
        out << linia << endl;
    }
    in.close();
    out.close();
}

#define READ(in, dana)  (in >> dana.liczba && getline(in, dana.slowo) && getline(in, dana.slowo) && getline(in, dana.litera) && \
    in >> dana.zestaw1.b >> dana.zestaw1.c >> dana.zestaw1.f && \
    in >> dana.zestaw2.b >> dana.zestaw2.c >> dana.zestaw2.f && \
    in >> dana.zestaw3.b >> dana.zestaw3.c >> dana.zestaw3.f && \
    in >> dana.zestaw4.b >> dana.zestaw4.c >> dana.zestaw4.f && \
    dana.zestaw1.obetnij() && dana.zestaw2.obetnij() && dana.zestaw3.obetnij() && dana.zestaw4.obetnij())

#define WRITE(out, dana) {out << dana.liczba << endl << dana.slowo << endl << dana.litera << endl; \
    out << dana.zestaw1.b << endl << dana.zestaw1.c << endl << dana.zestaw1.f << endl; \
    out << dana.zestaw2.b << endl << dana.zestaw2.c << endl << dana.zestaw2.f << endl; \
    out << dana.zestaw3.b << endl << dana.zestaw3.c << endl << dana.zestaw3.f << endl; \
    out << dana.zestaw4.b << endl << dana.zestaw4.c << endl << dana.zestaw4.f << endl;}

int znajdzNajmInt(string nazwa)
{
    ifstream in(nazwa.c_str());
    Dana dana;
    int najm = INT_MAKS;
    while(READ(in, dana))
    {
        cerr << dana.liczba << endl;
        if (dana.liczba < najm) najm = dana.liczba;
    }
    in.close();
    return najm;
}

int przepisz(string nazwa1, string nazwa2, string nazwa3, int najm)
{
    cerr << nazwa1 << " " << nazwa2 << " " << nazwa3 << " " << najm << endl;
    ifstream plik3(nazwa3.c_str());
    ofstream plik1(nazwa1.c_str(), ios_base::app);
    ofstream plik2(nazwa2.c_str());
    Dana dana;
    int nowyNajm = INT_MAKS;
    while (READ(plik3, dana))
    {
        if (najm == dana.liczba) WRITE(plik1, dana)
        else if (najm <= dana.liczba)
        {
            if (nowyNajm > dana.liczba) nowyNajm = dana.liczba;
            WRITE(plik2, dana)
        } else cerr << "MAMY PROBLEM: " << dana.liczba << " < " << najm << endl;
    }

    plik1.close();
    plik2.close();
    plik3.close();
    return nowyNajm;
}

void SortInt(string nazwa1, string nazwa2, string nazwa3)
{
    fstream plik1, plik2, plik3;
    kopiujPlik(nazwa1, nazwa3);
    ofstream clf(nazwa1.c_str());
    clf.close();

    Dana dana;
    int najm = znajdzNajmInt(nazwa3);
    while (true) {
        int nowyNajm = przepisz(nazwa1, nazwa2, nazwa3, najm);
        if (nowyNajm == najm)
            break;
        swap(nazwa2, nazwa3);
        najm = nowyNajm;
    }
}

string znajdzNajmString(string nazwa)
{
    ifstream in(nazwa.c_str());
    Dana dana;
    string najm;
    bool czy = true;
    while(READ(in, dana))
    {
        if (czy)
        {
            czy = false;
            najm = dana.slowo;
        }
        else if (dana.slowo < najm) najm = dana.slowo;
    }
    in.close();
    return najm;
}

string przepisz(string nazwa1, string nazwa2, string nazwa3, string najm)
{
    ifstream plik3(nazwa3.c_str());
    ofstream plik1(nazwa1.c_str(), ios_base::app);
    ofstream plik2(nazwa2.c_str());
    Dana dana;
    string nowyNajm;
    bool czy = true;
    while (READ(plik3, dana))
    {
        if (najm == dana.slowo) WRITE(plik1, dana)
        else if (najm < dana.slowo)
        {
            if (czy)
            {
                czy = false;
                nowyNajm = dana.slowo;
            }
            else if (nowyNajm > dana.slowo) nowyNajm = dana.slowo;
            WRITE(plik2, dana)
        } else cerr << "MAMY PROBLEM: " << dana.slowo << " < " << najm << endl;
    }

    plik1.close();
    plik2.close();
    plik3.close();
    return nowyNajm;
}

void SortString(string nazwa1, string nazwa2, string nazwa3)
{
    kopiujPlik(nazwa1, nazwa3);
    ofstream clf(nazwa1.c_str());
    clf.close();

    Dana dana;
    string najm = znajdzNajmString(nazwa3);
    while (true) {
        string nowyNajm = przepisz(nazwa1, nazwa2, nazwa3, najm);
        if (nowyNajm == najm)
            break;
        swap(nazwa2, nazwa3);
        najm = nowyNajm;
    }
}

bool operator==(Zestaw a, Zestaw b)
{
    return (a.b == b.b && a.c == b.c && a.f == b.f);
}

bool operator==(Dana a, Dana b)
{
    return (a.liczba == b.liczba && a.litera == b.litera && a.slowo == b.slowo
            && a.zestaw1 == b.zestaw1 && a.zestaw2 == b.zestaw2 && a.zestaw3 == b.zestaw3 && a.zestaw4 == b.zestaw4);
}

bool operator<(Dana a, Dana b)
{
    return (a.liczba < b.liczba
            || ((a.liczba == b.liczba) && ((a.zestaw1.c + a.zestaw2.c + a.zestaw3.c + a.zestaw4.c) % 256) < ((b.zestaw1.c + b.zestaw2.c + b.zestaw3.c + b.zestaw4.c) % 256)));
}

Dana znajdzNajwDana(string nazwa)
{
    ifstream in(nazwa.c_str());
    Dana dana;
    Dana najw;
    bool czy = true;
    while(READ(in, dana))
    {
        if (czy)
        {
            czy = false;
            najw = dana;
        }
        else if (najw < dana) najw = dana;
    }
    in.close();
    return najw;
}

bool czyRazem(Dana a, Dana b)
{
    return (a.liczba == b.liczba && (a.zestaw1.c + a.zestaw2.c + a.zestaw3.c + a.zestaw4.c) % 256 == (b.zestaw1.c + b.zestaw2.c + b.zestaw3.c +b.zestaw4.c) % 256);
}

Dana przepisz(string nazwa1, string nazwa2, string nazwa3, Dana najw)
{
    ifstream plik3(nazwa3.c_str());
    ofstream plik1(nazwa1.c_str(), ios_base::app);
    ofstream plik2(nazwa2.c_str());
    Dana dana;
    Dana nowyNajw;
    bool czy = true;
    while (READ(plik3, dana))
    {
        if (czyRazem(najw, dana)) WRITE(plik1, dana)
        else if (dana < najw)
        {
            if (czy)
            {
                czy = false;
                nowyNajw = dana;
            }
            else if (nowyNajw < dana) nowyNajw = dana;
            WRITE(plik2, dana)
        }
    }

    plik1.close();
    plik2.close();
    plik3.close();
    return nowyNajw;
}

void liczCiagi(string nazwa1, string nazwa2)
{
    ifstream in(nazwa1.c_str());
    ofstream out(nazwa2.c_str());
    Dana dana;
    int n;
    int i = 0;
    bool czy = true;
    while (READ(in, dana))
    {
        if (czy)
        {
            czy = false;
            n = dana.liczba;
        }
        if (dana.liczba != n)
        {
            out << n << " " << i << endl;
            n = dana.liczba;
            i = 0;
        }
        i++;
    }
    out << n << " " << i << endl;
    in.close();
    out.close();
}

int znajdzNastMaks(string nazwa, int popMaks)
{
    ifstream in(nazwa.c_str());
    int n, i;
    int maks = -1;
    bool czy = true;
    while (in >> n >> i)
    {
        if (czy && i < popMaks)
        {
            czy = false;
            maks = i;
        }
        else if (i > maks && i < popMaks) maks = i;
    }
    in.close();
    return maks;
}

void SortCount(string nazwa1, string nazwa2, string nazwa3)
{
    kopiujPlik(nazwa1, nazwa3);
    ofstream clf1(nazwa1.c_str());
    clf1.close();
    Dana dana;
    Dana najw = znajdzNajwDana(nazwa3);
    while (true) {
        Dana nowyNajw = przepisz(nazwa1, nazwa2, nazwa3, najw);
        if (czyRazem(nowyNajw, najw))
            break;
        swap(nazwa2, nazwa3);
        najw = nowyNajw;
    }
    liczCiagi(nazwa1, nazwa2);
    ofstream clf2(nazwa3.c_str());
    clf2.close();
    int maks = znajdzNastMaks(nazwa2, INT_MAKS);
    while (maks != -1)
    {
        int n, i;
        ifstream plik2(nazwa2.c_str());
        while (plik2 >> n >> i)
        {
            if (i == maks)
            {
                ifstream plik1(nazwa1.c_str());
                ofstream plik3(nazwa3.c_str(), ios_base::app);
                Dana dana;
                while (READ(plik1, dana))
                {
                    if (dana.liczba == n) WRITE(plik3, dana);
                }
                plik1.close();
                plik3.close();
            }
        }
        plik2.close();
        maks = znajdzNastMaks(nazwa2, maks);
    }
    kopiujPlik(nazwa3, nazwa1);
}
void SymmetricDifference(string nazwa1, string nazwa2, string nazwa3)
{
    ifstream plik2(nazwa2.c_str());
    ofstream plik3(nazwa3.c_str());
    Dana dana1, dana2;
    while (READ(plik2, dana1))
    {
        bool czyDodac = true;
        ifstream plik1(nazwa1.c_str());
        while (READ(plik1, dana2))
        {
            if (dana1 == dana2)
            {
                czyDodac = false;
                break;
            }
        }
        plik1.close();
        if (czyDodac)
        {
            ofstream plik1(nazwa1.c_str(), ios_base::app);
            WRITE(plik1, dana1);
            plik1.close();
        }
        else
        {
            WRITE(plik3, dana1);
        }
    }
    plik2.close();
    plik3.close();
    kopiujPlik(nazwa3, nazwa2);
}
