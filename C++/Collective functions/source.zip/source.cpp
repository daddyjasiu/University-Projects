//Jan Skwarczek


void Add(int value, int tab[]){
	
	if(value>0&&value<4096){
		
		int counter = 0;
		
		for(int i=0; tab[i]!=-1; i++){
			
			if(tab[i]>0&&tab[i]<4096) counter++;
			
		}
		
		for(int i=0; i<=counter; i++){
			
			if(tab[i]==value) break;
			
			else if(tab[i]==-1){
				
				tab[i] = value;
				tab[i+1] = (-1);
			}	
		}
	}
}

void Create(int n, int tab[], int mat[]){
	
	int repeat=0;
    int counter=0;

    for (int i=0; i<n; i++){
        for(int j=i+1; j<n; j++){
        	
            if(tab[i]==tab[j]){
                repeat=1;
            }
        }
        
        if(repeat==0&&tab[i]<4096&&tab[i]>0){
            mat[counter]=tab[i];
            counter++;
        }
        
        repeat=0;
    }
    
    mat[counter]=(-1);	
}

void Union(int tab[], int mat[], int sum[]){
	
    int counter=0;
    bool repeat=false;
    
    for(int i=0; tab[i]!=(-1); i++){
        sum[i]=tab[i];
        counter++;
    }
    
    for(int i=0; mat[i]!=(-1); i++){	
        for(int j=0; tab[j]!=(-1); j++){
        	
            if(tab[j]==mat[i]){
              repeat = true;
            }
        }
        
        if(!repeat){
            sum[counter]=mat[i];
            counter++;
        }
        
        repeat = false;
    }
    
    sum[counter]=(-1);
      
}

void Intersection(int tab[], int mat[], int inter[]){
    
	if(tab[0]==-1||mat[0]==-1) inter[0]=-1;
    
    else{
    	
    	int index=0;
    	
   		for(int i=0; tab[i]!=-1; i++){
        	for(int j=0; mat[j]!=-1; j++){
            
           		if(tab[i]==mat[j]){
              		inter[index] = tab[i];
                	index++; 
            	}
        	}
    	}
    	inter[index]=-1;
	}
}

void Difference(int tab[], int mat[], int dif[]){
	
	int counter=0;
    bool repeat=0;
    
    for(int i=0;tab[i]!=(-1);i++){
        for(int j=0;mat[j]!=(-1);j++){
        	
            if(tab[i]==mat[j]){
                repeat=true;
            }
        }
        
		if(repeat==0){
            dif[counter]=tab[i];
            counter++;
        }
        repeat=false;
    }
    
    dif[counter]=(-1);
    
}

void Complement(int tab[], int mat[]){
	
	int counter=0;
	bool repeat = false;
	
	
	for(int i=1; i!=4096; i++){
		for(int j=0; tab[j]!=-1; j++){
			
			if(i==tab[j]) repeat = true;
		}
		
		if(repeat==false){
			
			mat[counter] = i;
			counter++;
		}
		
		repeat = false;
	}
	
	mat[counter] = -1;
}

bool Subset(int tab[], int mat[]){
	
	int counter=0;
	int elem=0;
	
	for(int i=0; tab[i]!=-1; i++){
		
		if(tab[i]>0&&tab[i]<4096) elem++;
		
	}
	
	for(int i = 0; mat[i]!=-1; i++){
        for(int j=0; tab[j]!=-1; j++){
        
			if(mat[i]==tab[j]) counter++;
        	
		}
    }
    
    if(counter==elem) return true;
    else return false;
	
}

bool Equal(int tab[], int mat[]){
	
	int elem1 = 0;
	int elem2 = 0;
	int counter1 = 0;
	int counter2 = 0;
	
	for(int i=0; tab[i]!=-1; i++){
		
		if(tab[i]>0&&tab[i]<4096) elem1++;
		
	}
	
	for(int i=0; mat[i]!=-1; i++){
		
		if(mat[i]>0&&mat[i]<4096) elem2++;
		
	}
	
	for(int i=0; tab[i]!=-1; i++){
        for(int j=0; mat[j]!=-1; j++){
        
			if(tab[i]==mat[j]) counter1++;
		}
    }
    
    for(int i=0; mat[i]!=-1; i++){
        for(int j=0; tab[j]!=-1; j++){
        
			if(mat[i]==tab[j]) counter2++;
		}
    }
    
	if(counter1==elem1&&elem1==elem2&&counter2==elem2) return true;
    else return false;
}

bool Empty(int tab[]){
	
	if(tab[0]==-1)return true;
	else return false;
	
}

bool Nonempty(int tab[]){
	
	if(Empty(tab)==true) return false;
	else return true;
	
}

bool Element(int n, int tab[]){
	
	for(int i=0; tab[i]!=-1; i++){
		
		if(tab[i]==n) return true;
		
	}
	return false;
}

void Symmetric(int tab[], int mat[], int sym[]){
    
    Difference(tab, mat, sym);
    
    for(int i=0; mat[i]!=-1; i++ )
        if(Element(mat[i], tab)!=1)
            Add(mat[i], sym);
    
}

double Arithmetic(int tab[]){
	
	if(tab[0]==-1) return 0;
	
	else{
		
		double counter=0.0;
		double elem=0.0;
	
		for(int i=0; tab[i]!=-1; i++){
		
			if(tab[i]>0&&tab[i]<4096) elem++;
		
		}
	
		for(int i = 0; tab[i]!=-1; i++){
       	 
			counter+=tab[i];
        	
    	}
    	
    	return counter/elem;
		
	}
	
}

double Harmonic(int tab[]){
	
	if(tab[0]==-1) return 1;
	
	else{
		
		double counter = 0.0;
		double elem = 0.0;
	
		for(int i=0; tab[i]!=-1; i++){
		
			if(tab[i]>0&&tab[i]<4096) elem++;
			
		}
	
		for(int i = 0; tab[i]!=-1; i++){
       	 
			counter = counter + (1./tab[i]);
        	
    	}
    	
    	return elem/counter;
		
	}
	
}

void MinMax(int tab[], int *pmin, int &rmax){
	
	if(tab[0]!=-1){
		
		*pmin = tab[0];
		rmax = tab[0];
	
		for(int i=0; tab[i]!=-1; i++){
		
			if(tab[i]>=rmax) rmax=tab[i];
			if(tab[i]<=*pmin) *pmin=tab[i];	
		
		}
	}
	
}

void Cardinality(int tab[], int *pcard){
	
	*pcard = 0;
	
	for(int i=0; tab[i]!=-1; i++){
		
		if(tab[i]>0&&tab[i]<4096) *pcard = *pcard + 1;	
		
	}
	
}

void Properties(int tab[], char ciag[], double &rar, double *phar, int &rmin, int *pmax, int &rcar){
	
	int counter = 0;
	
	for(int i=0; ciag[i]!='\0'; i++)
		if(ciag[i]=='a'||ciag[i]=='h'||ciag[i]=='m'||ciag[i]=='c')
			counter++;
	
	for(int i=0; i<counter; i++){
		
		if(ciag[i]=='a'){
		
			rar = Arithmetic(tab);
		
		}
	
		else if(ciag[i]=='h'){
		
			*phar = Harmonic(tab);
		
		}
		
		else if(ciag[i]=='m'){
		
			if(tab[0]!=-1){
		
				rmin = tab[0];
				*pmax = tab[0];
	
				for(int i=0; tab[i]!=-1; i++){
		
					if(tab[i]>=*pmax) *pmax=tab[i];
					if(tab[i]<=rmin) rmin=tab[i];	
		
				}
			}	
		}
		
		else if(ciag[i]=='c'){
			
			rcar = 0;
			
			for(int i=0; tab[i]!=-1; i++){
		
				if(tab[i]>0&&tab[i]<4096) rcar = rcar + 1;	
		
			}
		
		}
		
	}
}














